
import asyncio
import json
from collections import defaultdict
from collections.abc import AsyncIterator
from datetime import datetime
from typing import Any


class PrivateEventManager:
    def __init__(self):
        # user_id -> set of connected subscriber queues
        self.subscribers: dict[
            int, set[asyncio.Queue]
        ] = defaultdict(set)

    def subscribe(self, user_id: int) -> asyncio.Queue:
        queue = asyncio.Queue(maxsize=100)
        self.subscribers[user_id].add(queue)
        return queue

    def unsubscribe(
        self,
        user_id: int,
        queue: asyncio.Queue,
    ):
        connections = self.subscribers.get(user_id)

        if connections is None:
            return

        connections.discard(queue)

        if not connections:
            self.subscribers.pop(user_id, None)

    def publish(
        self,
        user_ids: list[int],
        event: dict[str, Any],
    ):
        for user_id in set(user_ids):
            for queue in tuple(
                self.subscribers.get(user_id, ())
            ):
                try:
                    queue.put_nowait(event)
                except asyncio.QueueFull:
                    # A slow client will recover through
                    # a fresh database history request.
                    self.unsubscribe(user_id, queue)

    async def stream(
        self,
        user_id: int,
        queue: asyncio.Queue,
    ) -> AsyncIterator[str]:
        try:
            while True:
                try:
                    event = await asyncio.wait_for(
                        queue.get(),
                        timeout=20,
                    )

                    yield (
                        "event: private_message\n"
                        f"data: {json.dumps(event)}\n\n"
                    )

                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"

        finally:
            self.unsubscribe(user_id, queue)


private_events = PrivateEventManager()
