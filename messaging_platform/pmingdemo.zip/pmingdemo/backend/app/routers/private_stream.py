
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse

from ..models import User
from ..services.auth_dependency import require_user
from ..services.private_events import private_events

router = APIRouter(prefix="/api/private")


@router.get("/stream")
async def private_stream(
    user: User = Depends(require_user),
):
    queue = private_events.subscribe(user.id)

    return StreamingResponse(
        private_events.stream(user.id, queue),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "X-Accel-Buffering": "no",
        },
    )
